# 免责声明

服务仅供测试,正式使用请遵守法律法规,按照法定程序。

# 简介

e装机奕奕易档团队开发的手表应用市场目前测试版本0.2其他正在写如果你感兴趣也可以加入我们团队qq群431516892一起开发
我们的口号：易用，高档！易档市场！

<img src="https://www.hescompany.xyz:2087/fbdownload/QQ%E5%9B%BE%E7%89%8720230711232109_png.png?tid=%22fY4nnCbphoZnOQJaDNP_gOW2hQS8WsReSxazzalzwLrhsGfoGE3oPtidZrHetWhSUy2FQKwPoFgm-cwH%22&mode=open&dlink=%222f6e66636b6c2f65e8a385e69cbae69687e4bbb62fe5ba94e794a8e5b882e59cbae59bbee789872f5151e59bbee7898732303233303731313233323130395f706e672e706e67%22&stdhtml=true&SynoToken=ke4qKZ8m1z69w" width="210" height="297"/>
<img src="https://www.hescompany.xyz:2087/fbdownload/K)U%7BXGZ%60P%24Y%5D(%5DWXF%5DM%40660.png?tid=%22fY4nnCbphoZnOQJaDNP_gOW2hQS8WsReSxazzalzwLrhsGfoGE3oPtidZrHetWhSUy2FQKwPoFgm-cwH%22&mode=open&dlink=%222f6e66636b6c2f65e8a385e69cbae69687e4bbb62fe5ba94e794a8e5b882e59cbae59bbee789872f4b29557b58475a605024595d285d5758465d4d403636302e706e67%22&stdhtml=true&SynoToken=ke4qKZ8m1z69w" width="210" height="297"/>
# 关于我的QQ群
<img src="https://www.hescompany.xyz:2087/fbdownload/QQ%E7%BE%A4.jpg?tid=%22fY4nnCbphoZnOQJaDNP_gOW2hQS8WsReSxazzalzwLrhsGfoGE3oPtidZrHetWhSUy2FQKwPoFgm-cwH%22&mode=open&dlink=%222f6e66636b6c2f65e8a385e69cbae69687e4bbb62fe5ba94e794a8e5b882e59cbae59bbee789872f5151e7bea42e6a7067%22&stdhtml=true&SynoToken=ke4qKZ8m1z69w" width="600" height="450"/>
# 视频号
抖音+b站搜索：e装机
#公众号
edsq
中文搜索易档社区
<img src="https://www.hescompany.xyz:2087/fbdownload/QQ%E5%9B%BE%E7%89%8720230520222950.png?tid=%22fY4nnCbphoZnOQJaDNP_gOW2hQS8WsReSxazzalzwLrhsGfoGE3oPtidZrHetWhSUy2FQKwPoFgm-cwH%22&mode=open&dlink=%222f6e66636b6c2f65e8a385e69cbae69687e4bbb62fe5ba94e794a8e5b882e59cbae59bbee789872f5151e59bbee7898732303233303532303232323935302e706e67%22&stdhtml=true&SynoToken=ke4qKZ8m1z69w" width="500" height="200"/>


## 特点优势+导入步骤
1、简洁
2、安装速度快
3、功能多
4、易档团队开发
5，手表安卓适配好最低适配4.4
1. HBuilder X导入
（更多功能持续更新中~）

## 官网地址
1.社区edsq.top
2.以前的社区ydvm.xyz
3.官网后续开发
## 一些图片只支持ip6网络访问
<img src="https://www.hescompany.xyz:2087/fbdownload/1.png?tid=%22fY4nnCbphoZnOQJaDNP_gOW2hQS8WsReSxazzalzwLrhsGfoGE3oPtidZrHetWhSUy2FQKwPoFgm-cwH%22&mode=open&dlink=%222f6e66636b6c2f65e8a385e69cbae69687e4bbb62fe5ba94e794a8e5b882e59cbae59bbee789872f312e706e67%22&stdhtml=true&SynoToken=ke4qKZ8m1z69w" width="600" height="450"/>
<img src="https://www.hescompany.xyz:2087/fbdownload/2.png?tid=%22fY4nnCbphoZnOQJaDNP_gOW2hQS8WsReSxazzalzwLrhsGfoGE3oPtidZrHetWhSUy2FQKwPoFgm-cwH%22&mode=open&dlink=%222f6e66636b6c2f65e8a385e69cbae69687e4bbb62fe5ba94e794a8e5b882e59cbae59bbee789872f322e706e67%22&stdhtml=true&SynoToken=ke4qKZ8m1z69w" width="600" height="450"/>
<img src="https://www.hescompany.xyz:2087/fbdownload/3.png?tid=%22fY4nnCbphoZnOQJaDNP_gOW2hQS8WsReSxazzalzwLrhsGfoGE3oPtidZrHetWhSUy2FQKwPoFgm-cwH%22&mode=open&dlink=%222f6e66636b6c2f65e8a385e69cbae69687e4bbb62fe5ba94e794a8e5b882e59cbae59bbee789872f332e706e67%22&stdhtml=true&SynoToken=ke4qKZ8m1z69w" width="600" height="450"/>
<img src="https://www.hescompany.xyz:2087/fbdownload/4.png?tid=%22fY4nnCbphoZnOQJaDNP_gOW2hQS8WsReSxazzalzwLrhsGfoGE3oPtidZrHetWhSUy2FQKwPoFgm-cwH%22&mode=open&dlink=%222f6e66636b6c2f65e8a385e69cbae69687e4bbb62fe5ba94e794a8e5b882e59cbae59bbee789872f342e706e67%22&stdhtml=true&SynoToken=ke4qKZ8m1z69w" width="600" height="450"/>
<img src="https://www.hescompany.xyz:2087/fbdownload/5.png?tid=%22fY4nnCbphoZnOQJaDNP_gOW2hQS8WsReSxazzalzwLrhsGfoGE3oPtidZrHetWhSUy2FQKwPoFgm-cwH%22&mode=open&dlink=%222f6e66636b6c2f65e8a385e69cbae69687e4bbb62fe5ba94e794a8e5b882e59cbae59bbee789872f352e706e67%22&stdhtml=true&SynoToken=ke4qKZ8m1z69w" width="600" height="450"/>
<img src="https://www.hescompany.xyz:2087/fbdownload/6.png?tid=%22fY4nnCbphoZnOQJaDNP_gOW2hQS8WsReSxazzalzwLrhsGfoGE3oPtidZrHetWhSUy2FQKwPoFgm-cwH%22&mode=open&dlink=%222f6e66636b6c2f65e8a385e69cbae69687e4bbb62fe5ba94e794a8e5b882e59cbae59bbee789872f362e706e67%22&stdhtml=true&SynoToken=ke4qKZ8m1z69w" width="210" height="297"/>
<img src="https://www.hescompany.xyz:2087/fbdownload/7.png?tid=%22fY4nnCbphoZnOQJaDNP_gOW2hQS8WsReSxazzalzwLrhsGfoGE3oPtidZrHetWhSUy2FQKwPoFgm-cwH%22&mode=open&dlink=%222f6e66636b6c2f65e8a385e69cbae69687e4bbb62fe5ba94e794a8e5b882e59cbae59bbee789872f372e706e67%22&stdhtml=true&SynoToken=ke4qKZ8m1z69w" width="600" height="450"/>
<img src="https://www.hescompany.xyz:2087/fbdownload/QQ%E5%9B%BE%E7%89%8720230708213408.png?tid=%22fY4nnCbphoZnOQJaDNP_gOW2hQS8WsReSxazzalzwLrhsGfoGE3oPtidZrHetWhSUy2FQKwPoFgm-cwH%22&mode=open&dlink=%222f6e66636b6c2f65e8a385e69cbae69687e4bbb62fe5ba94e794a8e5b882e59cbae59bbee789872f5151e59bbee7898732303233303730383231333430382e706e67%22&stdhtml=true&SynoToken=ke4qKZ8m1z69w" width="210" height="297"/>
## 支持团队
<img src="https://www.hescompany.xyz:2087/fbdownload/QQ%E5%9B%BE%E7%89%8720230712225724.jpg?tid=%22fY4nnCbphoZnOQJaDNP_gOW2hQS8WsReSxazzalzwLrhsGfoGE3oPtidZrHetWhSUy2FQKwPoFgm-cwH%22&mode=open&dlink=%222f6e66636b6c2f65e8a385e69cbae69687e4bbb62fe5ba94e794a8e5b882e59cbae59bbee789872f5151e59bbee7898732303233303731323232353732342e6a7067%22&stdhtml=true&SynoToken=ke4qKZ8m1z69w" width="210 height="297"/>